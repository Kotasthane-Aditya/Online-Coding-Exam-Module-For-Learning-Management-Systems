package com.reference;

public enum Language {
	JAVA, PYTHON, C,
}
