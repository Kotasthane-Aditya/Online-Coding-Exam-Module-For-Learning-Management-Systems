package com.reference;


public enum Input {
	SOURCE, FILE_PATH,
}
