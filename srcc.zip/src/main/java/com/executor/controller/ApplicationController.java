package com.executor.controller;

import com.executor.service.ExecutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class ApplicationController {

    @Autowired
    private ExecutorService executorService;

    @RequestMapping(path = "/sourceExecutor", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<String> executorServiceSource(@RequestBody String Data) throws IOException {
        return this.executorService.executorServiceSource(Data);
    }
}
