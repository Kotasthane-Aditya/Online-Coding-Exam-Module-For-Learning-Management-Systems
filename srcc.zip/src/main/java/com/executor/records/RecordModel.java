package com.executor.records;

import javax.persistence.*;

@Entity
@Table(name = "show_save_code")
public class RecordModel {

    @Id
    @Column(name = "roll_no")
    private int rollNo;

    @Column(name = "java", columnDefinition = "TEXT")
    private String java;

    @Column(name = "c", columnDefinition = "TEXT")
    private String c;

    @Column(name = "python", columnDefinition = "TEXT")
    private String python;

    public RecordModel() {}

    public RecordModel(int rollNo, String java, String c, String python) {
        this.rollNo = rollNo;
        this.java = java;
        this.c = c;
        this.python = python;
    }

    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getJava() {
        return java;
    }

    public void setJava(String java) {
        this.java = java;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getPython() {
        return python;
    }

    public void setPython(String python) {
        this.python = python;
    }
}
