package com.executor.languages.languageRepository;

import com.executor.languages.languageModel.LanguageModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageRepo extends JpaRepository<LanguageModel, Integer> {
}
