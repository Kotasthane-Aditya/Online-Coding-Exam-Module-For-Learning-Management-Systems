package com.executor.languages.languageModel;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "languages")
public class LanguageModel {

    @Id
    private Integer qId;

    private String java;

    private String c;

    private String python;

    public LanguageModel() {
    }

    public LanguageModel(Integer qId, String java, String c, String python) {
        this.qId = qId;
        this.java = java;
        this.c = c;
        this.python = python;
    }

    public Integer getQId() {
        return qId;
    }

    public void setQId(Integer qId) {
        this.qId = qId;
    }

    public String getJava() {
        return java;
    }

    public void setJava(String java) {
        this.java = java;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getPython() {
        return python;
    }

    public void setPython(String python) {
        this.python = python;
    }
}
