package com.executor.languages.languageService;

import com.executor.languages.languageModel.LanguageModel;
import com.executor.languages.languageRepository.LanguageRepo;
import com.executor.languages.languageService.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class LanguageServiceImpl implements LanguageService {

    @Autowired
    private LanguageRepo languageRepo;

    @Override
    public LanguageModel saveLanguage(LanguageModel language) {
        return languageRepo.save(language);
    }

    @Override
    public List<LanguageModel> getAllLanguages() {
        return languageRepo.findAll();
    }

    @Override
    public LanguageModel getLanguageById(Integer id) {
        return languageRepo.findById(id).orElse(null);
    }

    @Override
    public LanguageModel updateLanguage(Integer id, LanguageModel updatedLanguage) {
        Optional<LanguageModel> existingLanguage = languageRepo.findById(id);
        if (existingLanguage.isPresent()) {
            LanguageModel language = existingLanguage.get();
            language.setJava(updatedLanguage.getJava());
            language.setC(updatedLanguage.getC());
            language.setPython(updatedLanguage.getPython());
            return languageRepo.save(language);
        }
        return null;
    }

    @Override
    public void deleteLanguage(Integer id) {
        languageRepo.deleteById(id);
    }
}
