package com.executor.languages.languageService;

import com.executor.languages.languageModel.LanguageModel;

import java.util.List;

public interface LanguageService {
    LanguageModel saveLanguage(LanguageModel language);
    List<LanguageModel> getAllLanguages();
    LanguageModel getLanguageById(Integer id);
    LanguageModel updateLanguage(Integer id, LanguageModel updatedLanguage);
    void deleteLanguage(Integer id);
}
