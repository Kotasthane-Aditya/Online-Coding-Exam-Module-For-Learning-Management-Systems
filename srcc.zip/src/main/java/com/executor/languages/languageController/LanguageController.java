package com.executor.languages.languageController;

import com.executor.languages.languageModel.LanguageModel;
import com.executor.languages.languageService.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/languages")
public class LanguageController {

    @Autowired
    private LanguageService languageService;

    @PostMapping
    public LanguageModel saveLanguage(@RequestBody LanguageModel language) {
        return languageService.saveLanguage(language);
    }

    @GetMapping
    public List<LanguageModel> getAllLanguages() {
        return languageService.getAllLanguages();
    }

    @GetMapping("/{id}")
    public LanguageModel getLanguageById(@PathVariable Integer id) {
        return languageService.getLanguageById(id);
    }

    @PutMapping("/{id}")
    public LanguageModel updateLanguage(@PathVariable Integer id, @RequestBody LanguageModel language) {
        return languageService.updateLanguage(id, language);
    }

    @DeleteMapping("/{id}")
    public String deleteLanguage(@PathVariable Integer id) {
        languageService.deleteLanguage(id);
        return "Language entry deleted!";
    }
}
