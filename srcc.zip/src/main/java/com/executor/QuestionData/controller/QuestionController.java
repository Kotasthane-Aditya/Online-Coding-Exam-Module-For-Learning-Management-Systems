package com.executor.QuestionData.controller;

import com.executor.QuestionData.model.QuestionModel;
import com.executor.QuestionData.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/question")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @GetMapping("/{q_id}")
    public QuestionModel getQuestion(@PathVariable Integer q_id) {
        return questionService.getQuestion(q_id);
    }

    @GetMapping
    public List<QuestionModel> getAllQuestions() {
        System.out.println("hello...");
        return questionService.getAllQuestions();
    }
}
