package com.executor.studentsData.studentModel;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class StudentModel {
    @Id
    private int roll_no;
    private Integer question_assign;  // Nullable field
    private String remark;            // Nullable field

    public StudentModel() {}

    public int getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(int roll_no) {
        this.roll_no = roll_no;
    }

    public Integer getQuestion_assign() {
        return question_assign;
    }

    public void setQuestion_assign(Integer question_assign) {
        this.question_assign = question_assign;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
